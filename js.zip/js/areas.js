
    function media() {
        var n1, n2, area;
        n1=forMedia.base1.value;
        n2=forMedia.altura1.value;
        n1=parseFloat(n1);
        n2=parseFloat(n2);
        area=(n1*n2)/2;
        
            document.getElementById("resultado").innerHTML=
            "A area da figura é:" + area;
    
    }
    
    function cubo()
    {
        var n1, area;
        n1 = forcubo.aresta.value;
        n1= parseFloat(n1);
        area = 6 * Math.pow(n1,2);
        document.getElementById("resultado").innerHTML=
            "A area da figura é:" + area + "m²";
    }
    
    
    function circulo()
    {
        var n1,area;
        n1= forcirculo.raio.value;
        n1 = parseFloat(n1);
        area = Math.PI * Math.pow(n1,2);
        document.getElementById("resultado").innerHTML=
            "A area da figura é:" + area.toFixed(4) + "m²";
    }
    
    function cilindro()
    {
        var n1,n2,n3,area;
        n1 = forcilindro.raio1.value;
        n2 = forcilindro.altura1.value;
        n1 = parseFloat(n1);
        n2 = parseFloat(n2);
       
        area = 2 * Math.PI * n1 * (n1+n2);
        document.getElementById("resultado").innerHTML=
            "A area da figura é:" + area.toFixed(2) + "m²";
    
    }